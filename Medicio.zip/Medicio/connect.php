<?php
    // session_start();
    $host='localhost';
    $user='root';
    $password='';
    $con=mysqli_connect($host,$user,$password,'nn_db');
?>